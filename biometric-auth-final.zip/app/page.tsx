"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Activity, Clock, Fingerprint, ShieldCheck, BarChart3, Settings, AlertTriangle } from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarProvider,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar"
import { verifyUser, registerUser, analyzeTypingData } from "./actions"
import { UserPatterns } from "@/components/user-patterns"
import type { TypingData, AuthResult } from "@/types"
import { TypingCollector } from "@/components/typing-collector"
import { TypingVisualizer } from "@/components/typing-visualizer"

// Add this interface before the BiometricAuth component
interface MetricCardProps {
  icon: React.ElementType
  label: string
  value: string
  color: string
  progress?: number
}

// Add this function before the BiometricAuth component
function MetricCard({ icon: Icon, label, value, color, progress }: MetricCardProps) {
  return (
    <div className="rounded-lg bg-gray-900/50 border border-purple-900/30 p-3 space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`p-1.5 rounded-md bg-gradient-to-r ${color} bg-opacity-10`}>
            <Icon className="h-4 w-4 text-white" />
          </div>
          <span className="text-xs font-medium text-gray-400">{label}</span>
        </div>
        <span className={`text-sm font-bold bg-gradient-to-r ${color} bg-clip-text text-transparent`}>{value}</span>
      </div>

      {progress !== undefined && (
        <div className="h-1.5 w-full bg-gray-800 rounded-full overflow-hidden">
          <div className={`h-full bg-gradient-to-r ${color} rounded-full`} style={{ width: `${progress}%` }} />
        </div>
      )}
    </div>
  )
}

export default function BiometricAuth() {
  const [username, setUsername] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [authResult, setAuthResult] = useState<AuthResult | null>(null)
  const [activeTab, setActiveTab] = useState("login")
  const [activeSidebarTab, setActiveSidebarTab] = useState("metrics")
  const [typingMetrics, setTypingMetrics] = useState<any>(null)
  const [verificationText, setVerificationText] = useState(
    "The quick brown fox jumps over the lazy dog. Security through behavior is the future of authentication.",
  )

  // Handle typing verification
  const handleTypingVerification = async (typingData: TypingData) => {
    setIsAnalyzing(true)
    setAuthResult(null)
    setProgress(0)

    // Simulate progress animation
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 95) {
          clearInterval(interval)
          return 95
        }
        return prev + 5
      })
    }, 100)

    try {
      // Create form data
      const formData = new FormData()
      formData.append("username", username)
      formData.append("typingData", JSON.stringify(typingData))

      // Call the appropriate server action based on active tab
      const result = activeTab === "login" ? await verifyUser(formData) : await registerUser(formData)

      // Complete the progress bar
      setProgress(100)

      if (activeTab === "login") {
        setAuthResult(result as AuthResult)
      } else {
        // For registration, create a simple result object
        setAuthResult({
          success: result.success,
          confidenceScore: 100,
          metrics: {
            wpm:
              typingData.text.split(/\s+/).length /
              ((typingData.keyEvents[typingData.keyEvents.length - 1].timestamp - typingData.keyEvents[0].timestamp) /
                1000 /
                60),
            keyHoldTime: 0,
            rhythmConsistency: 90,
            confidenceScore: 100,
          },
          message: result.message,
        })
      }

      // Analyze typing data for visualization
      const analysisFormData = new FormData()
      analysisFormData.append("typingData", JSON.stringify(typingData))
      const analysis = await analyzeTypingData(analysisFormData)

      if (analysis.success && analysis.metrics) {
        setTypingMetrics(analysis.metrics)
      }
    } catch (error) {
      console.error("Error:", error)
      setAuthResult({
        success: false,
        confidenceScore: 0,
        metrics: { wpm: 0, keyHoldTime: 0, rhythmConsistency: 0, confidenceScore: 0 },
        message: "An error occurred",
      })
    } finally {
      clearInterval(interval)
      setIsAnalyzing(false)
      setProgress(100)
    }
  }

  // Reset form when changing tabs
  useEffect(() => {
    setAuthResult(null)
    setTypingMetrics(null)
  }, [activeTab])

  return (
    <SidebarProvider>
      <div className="flex min-h-screen bg-black text-white">
        <Sidebar className="border-r border-purple-900/30">
          <SidebarHeader className="p-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-6 w-6 text-purple-400" />
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                BioAuth
              </h1>
            </div>
          </SidebarHeader>

          <SidebarContent>
            <SidebarGroup>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton
                    isActive={activeSidebarTab === "metrics"}
                    onClick={() => setActiveSidebarTab("metrics")}
                  >
                    <Activity className="h-4 w-4 mr-2" />
                    <span>Metrics</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton
                    isActive={activeSidebarTab === "patterns"}
                    onClick={() => setActiveSidebarTab("patterns")}
                  >
                    <BarChart3 className="h-4 w-4 mr-2" />
                    <span>Typing Patterns</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton
                    isActive={activeSidebarTab === "settings"}
                    onClick={() => setActiveSidebarTab("settings")}
                  >
                    <Settings className="h-4 w-4 mr-2" />
                    <span>Settings</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroup>

            {activeSidebarTab === "metrics" && (
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-medium text-gray-400">BIOMETRIC METRICS</SidebarGroupLabel>
                <SidebarGroupContent>
                  <div className="space-y-6 p-2">
                    <MetricCard
                      icon={Activity}
                      label="Typing Speed"
                      value={`${Math.round(authResult?.metrics.wpm || 0)} WPM`}
                      color="from-blue-500 to-cyan-400"
                    />

                    <MetricCard
                      icon={Clock}
                      label="Key Hold Time"
                      value={`${Math.round(authResult?.metrics.keyHoldTime || 0)} ms`}
                      color="from-purple-500 to-pink-400"
                    />

                    <MetricCard
                      icon={ShieldCheck}
                      label="Rhythm Consistency"
                      value={`${Math.round(authResult?.metrics.rhythmConsistency || 0)}%`}
                      color="from-emerald-500 to-teal-400"
                      progress={authResult?.metrics.rhythmConsistency || 0}
                    />

                    <MetricCard
                      icon={Fingerprint}
                      label="Confidence Score"
                      value={`${Math.round(authResult?.metrics.confidenceScore || 0)}%`}
                      color="from-amber-500 to-orange-400"
                      progress={authResult?.metrics.confidenceScore || 0}
                    />
                  </div>
                </SidebarGroupContent>
              </SidebarGroup>
            )}

            {activeSidebarTab === "patterns" && username && (
              <SidebarGroup>
                <SidebarGroupContent>
                  <div className="p-2">
                    <UserPatterns username={username} />
                  </div>
                </SidebarGroupContent>
              </SidebarGroup>
            )}

            {activeSidebarTab === "settings" && (
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-medium text-gray-400">SETTINGS</SidebarGroupLabel>
                <SidebarGroupContent>
                  <div className="space-y-4 p-2">
                    <div className="space-y-2">
                      <label className="text-xs font-medium text-gray-400">Verification Text</label>
                      <textarea
                        value={verificationText}
                        onChange={(e) => setVerificationText(e.target.value)}
                        className="w-full h-24 p-2 text-xs rounded-md bg-gray-900/50 border border-purple-900/50 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                      />
                    </div>

                    <div className="p-3 rounded-md bg-yellow-900/20 border border-yellow-800/30">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="h-4 w-4 text-yellow-400 mt-0.5" />
                        <div className="text-xs text-yellow-400">
                          <p className="font-medium">Privacy Notice</p>
                          <p className="mt-1">
                            Your typing patterns are stored securely and used only for authentication purposes. You can
                            delete your patterns at any time.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SidebarGroupContent>
              </SidebarGroup>
            )}
          </SidebarContent>

          <SidebarFooter className="p-4">
            <div className="text-xs text-gray-500">Behavioral Biometrics v1.0</div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 p-8 overflow-y-auto">
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                Biometric Authentication
              </h2>
              <p className="mt-2 text-gray-400">Verify your identity through typing behavior</p>
            </div>

            <div className="bg-gray-900/30 border border-purple-900/30 rounded-lg p-6 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-medium text-white">Authentication</h3>
                  <p className="text-gray-400 text-sm mt-1">
                    {activeTab === "login"
                      ? "Verify your identity through typing behavior"
                      : "Create your typing profile"}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setActiveTab("login")}
                    className={`px-4 py-2 rounded-md text-sm ${
                      activeTab === "login"
                        ? "bg-purple-900/50 text-purple-300"
                        : "bg-gray-800/50 text-gray-400 hover:bg-gray-800"
                    }`}
                  >
                    Login
                  </button>
                  <button
                    onClick={() => setActiveTab("register")}
                    className={`px-4 py-2 rounded-md text-sm ${
                      activeTab === "register"
                        ? "bg-purple-900/50 text-purple-300"
                        : "bg-gray-800/50 text-gray-400 hover:bg-gray-800"
                    }`}
                  >
                    Register
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="username" className="text-sm font-medium text-gray-300">
                    Username
                  </label>
                  <input
                    id="username"
                    placeholder="Enter your username"
                    className="w-full p-2 rounded-md bg-gray-900/50 border border-purple-900/50 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </div>

                <TypingCollector
                  verificationText={verificationText}
                  onComplete={handleTypingVerification}
                  isSubmitting={isAnalyzing}
                />
              </div>

              {authResult && (
                <div
                  className={`p-4 rounded-md text-center font-medium ${
                    authResult.success
                      ? "bg-emerald-900/20 text-emerald-400 border border-emerald-800/30"
                      : "bg-red-900/20 text-red-400 border border-red-800/30"
                  }`}
                  style={{
                    boxShadow: authResult.success
                      ? "0 0 15px rgba(16, 185, 129, 0.2)"
                      : "0 0 15px rgba(239, 68, 68, 0.2)",
                  }}
                >
                  {authResult.success ? (
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-xl">✅</span>
                      <span>{activeTab === "login" ? "Login Successful" : "Registration Successful"}</span>
                      {authResult.adaptiveLearning && (
                        <span className="text-xs bg-blue-900/30 text-blue-400 px-2 py-1 rounded-full ml-2">
                          Pattern Learned
                        </span>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-xl">❌</span>
                      <span>{authResult.message}</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            {typingMetrics && (
              <div className="bg-gray-900/30 border border-purple-900/30 rounded-lg p-6 space-y-6">
                <h3 className="text-xl font-medium text-white">Typing Analysis</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-gray-300">Key Hold Times</h4>
                    <TypingVisualizer metrics={typingMetrics} type="holdTimes" />
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-gray-300">Typing Rhythm</h4>
                    <TypingVisualizer metrics={typingMetrics} type="rhythm" />
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </SidebarProvider>
  )
}
