"use server"

import type { AuthResult, TypingData } from "@/types"
import { authenticateUser, calculateTypingPattern, extractTypingMetrics } from "@/lib/biometrics"
import {
  createUser,
  findUserByUsername,
  addTypingPattern,
  getRecentTypingPatterns,
  deleteTypingPattern,
} from "@/lib/db"

export async function verifyUser(formData: FormData): Promise<AuthResult> {
  const username = formData.get("username") as string
  const typingDataJson = formData.get("typingData") as string

  if (!username || !typingDataJson) {
    return {
      success: false,
      confidenceScore: 0,
      metrics: { wpm: 0, keyHoldTime: 0, rhythmConsistency: 0, confidenceScore: 0 },
      message: "Missing required data",
    }
  }

  try {
    const typingData = JSON.parse(typingDataJson) as TypingData
    return await authenticateUser(username, typingData)
  } catch (error) {
    console.error("Authentication error:", error)
    return {
      success: false,
      confidenceScore: 0,
      metrics: { wpm: 0, keyHoldTime: 0, rhythmConsistency: 0, confidenceScore: 0 },
      message: "Authentication error",
    }
  }
}

export async function registerUser(
  formData: FormData,
): Promise<{ success: boolean; message: string; userId?: string }> {
  const username = formData.get("username") as string
  const typingDataJson = formData.get("typingData") as string

  if (!username || !typingDataJson) {
    return { success: false, message: "Missing required data" }
  }

  try {
    // Check if user already exists
    const existingUser = await findUserByUsername(username)
    if (existingUser) {
      return { success: false, message: "Username already exists" }
    }

    const typingData = JSON.parse(typingDataJson) as TypingData
    const typingPattern = calculateTypingPattern(typingData)

    const user = await createUser(username, typingPattern)
    return { success: true, message: "User registered successfully", userId: user.id }
  } catch (error) {
    console.error("Registration error:", error)
    return { success: false, message: "Registration failed" }
  }
}

export async function updateTypingPattern(formData: FormData): Promise<{ success: boolean; message: string }> {
  const username = formData.get("username") as string
  const typingDataJson = formData.get("typingData") as string

  if (!username || !typingDataJson) {
    return { success: false, message: "Missing required data" }
  }

  try {
    const user = await findUserByUsername(username)
    if (!user) {
      return { success: false, message: "User not found" }
    }

    const typingData = JSON.parse(typingDataJson) as TypingData
    const typingPattern = calculateTypingPattern(typingData)

    await addTypingPattern(user.id, typingPattern)
    return { success: true, message: "Typing pattern updated successfully" }
  } catch (error) {
    console.error("Update error:", error)
    return { success: false, message: "Update failed" }
  }
}

export async function getUserPatterns(formData: FormData): Promise<{
  success: boolean
  patterns?: any[]
  message?: string
}> {
  const username = formData.get("username") as string

  if (!username) {
    return { success: false, message: "Missing username" }
  }

  try {
    const user = await findUserByUsername(username)
    if (!user) {
      return { success: false, message: "User not found" }
    }

    const patterns = await getRecentTypingPatterns(user.id)

    // Format patterns for display
    const formattedPatterns = patterns.map((pattern) => ({
      id: pattern.id,
      wpm: pattern.averageWpm,
      consistency: Math.round((1 - pattern.varianceScore) * 100),
      device: pattern.environmentInfo.deviceType,
      timeOfDay: pattern.environmentInfo.timeOfDay,
      date: pattern.lastUpdated.toLocaleDateString(),
      keyCount: Object.keys(pattern.keyHoldTimes).length,
    }))

    return { success: true, patterns: formattedPatterns }
  } catch (error) {
    console.error("Error fetching patterns:", error)
    return { success: false, message: "Failed to fetch patterns" }
  }
}

export async function removePattern(formData: FormData): Promise<{ success: boolean; message: string }> {
  const username = formData.get("username") as string
  const patternId = formData.get("patternId") as string

  if (!username || !patternId) {
    return { success: false, message: "Missing required data" }
  }

  try {
    const user = await findUserByUsername(username)
    if (!user) {
      return { success: false, message: "User not found" }
    }

    const success = await deleteTypingPattern(user.id, patternId)
    return {
      success,
      message: success ? "Pattern deleted successfully" : "Pattern not found",
    }
  } catch (error) {
    console.error("Error removing pattern:", error)
    return { success: false, message: "Failed to remove pattern" }
  }
}

export async function analyzeTypingData(formData: FormData): Promise<{
  success: boolean
  metrics?: any
  message?: string
}> {
  const typingDataJson = formData.get("typingData") as string

  if (!typingDataJson) {
    return { success: false, message: "Missing typing data" }
  }

  try {
    const typingData = JSON.parse(typingDataJson) as TypingData
    const metrics = extractTypingMetrics(typingData)

    return { success: true, metrics }
  } catch (error) {
    console.error("Analysis error:", error)
    return { success: false, message: "Analysis failed" }
  }
}
