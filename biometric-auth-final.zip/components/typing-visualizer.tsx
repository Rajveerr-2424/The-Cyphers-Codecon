"use client"

import { useEffect, useRef } from "react"

interface TypingVisualizerProps {
  metrics: {
    keyHoldTimes?: Record<string, number[]>
    intervals?: number[]
    speedOverTime?: { time: number; wpm: number }[]
    keyFrequency?: Record<string, number>
  }
  type: "holdTimes" | "rhythm" | "speed"
  height?: number
}

export function TypingVisualizer({ metrics, type, height = 200 }: TypingVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set canvas styling
    ctx.lineWidth = 2
    ctx.lineCap = "round"
    ctx.lineJoin = "round"

    switch (type) {
      case "holdTimes":
        drawKeyHoldTimes(ctx, canvas, metrics.keyHoldTimes || {})
        break
      case "rhythm":
        drawTypingRhythm(ctx, canvas, metrics.intervals || [])
        break
      case "speed":
        drawTypingSpeed(ctx, canvas, metrics.speedOverTime || [])
        break
    }
  }, [metrics, type])

  // Draw key hold times visualization
  const drawKeyHoldTimes = (
    ctx: CanvasRenderingContext2D,
    canvas: HTMLCanvasElement,
    keyHoldTimes: Record<string, number[]>,
  ) => {
    const keys = Object.keys(keyHoldTimes).filter((key) => keyHoldTimes[key].length > 0)
    if (keys.length === 0) return

    // Calculate average hold time for each key
    const avgHoldTimes = keys.map((key) => ({
      key,
      avg: keyHoldTimes[key].reduce((sum, time) => sum + time, 0) / keyHoldTimes[key].length,
    }))

    // Sort by average hold time
    avgHoldTimes.sort((a, b) => a.avg - b.avg)

    // Find min and max for scaling
    const minTime = Math.min(...avgHoldTimes.map((k) => k.avg))
    const maxTime = Math.max(...avgHoldTimes.map((k) => k.avg))
    const range = maxTime - minTime || 1

    // Draw bars
    const barWidth = canvas.width / (keys.length + 1)
    const padding = barWidth * 0.2
    const maxBarHeight = canvas.height - 40

    // Draw title
    ctx.fillStyle = "#f1f5f9"
    ctx.font = "14px sans-serif"
    ctx.textAlign = "center"
    ctx.fillText("Key Hold Times (ms)", canvas.width / 2, 20)

    // Draw bars
    avgHoldTimes.forEach((item, i) => {
      const x = (i + 0.5) * barWidth
      const normalizedHeight = ((item.avg - minTime) / range) * maxBarHeight
      const barHeight = Math.max(normalizedHeight, 5)
      const y = canvas.height - barHeight - 20

      // Create gradient
      const gradient = ctx.createLinearGradient(x, y, x, canvas.height - 20)
      gradient.addColorStop(0, "#8b5cf6")
      gradient.addColorStop(1, "#3b82f6")

      // Draw bar
      ctx.fillStyle = gradient
      ctx.fillRect(x - barWidth / 2 + padding, y, barWidth - padding * 2, barHeight)

      // Draw key label
      ctx.fillStyle = "#f1f5f9"
      ctx.font = "12px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(item.key, x, canvas.height - 5)

      // Draw time value
      ctx.fillText(Math.round(item.avg).toString(), x, y - 5)
    })
  }

  // Draw typing rhythm visualization
  const drawTypingRhythm = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, intervals: number[]) => {
    if (intervals.length < 2) return

    // Draw title
    ctx.fillStyle = "#f1f5f9"
    ctx.font = "14px sans-serif"
    ctx.textAlign = "center"
    ctx.fillText("Typing Rhythm (intervals between keystrokes)", canvas.width / 2, 20)

    // Find min and max for scaling
    const minInterval = Math.min(...intervals)
    const maxInterval = Math.max(...intervals)
    const range = maxInterval - minInterval || 1

    // Draw line chart
    const padding = 30
    const chartWidth = canvas.width - padding * 2
    const chartHeight = canvas.height - padding * 2 - 20
    const pointSpacing = chartWidth / (intervals.length - 1)

    // Draw axes
    ctx.strokeStyle = "#475569"
    ctx.beginPath()
    ctx.moveTo(padding, padding + 20)
    ctx.lineTo(padding, canvas.height - padding)
    ctx.lineTo(canvas.width - padding, canvas.height - padding)
    ctx.stroke()

    // Draw rhythm line
    ctx.beginPath()
    ctx.strokeStyle = "#8b5cf6"
    ctx.lineWidth = 2

    intervals.forEach((interval, i) => {
      const x = padding + i * pointSpacing
      const normalizedValue = (interval - minInterval) / range
      const y = canvas.height - padding - normalizedValue * chartHeight

      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }

      // Draw point
      ctx.fillStyle = "#3b82f6"
      ctx.beginPath()
      ctx.arc(x, y, 3, 0, Math.PI * 2)
      ctx.fill()
    })

    ctx.stroke()

    // Draw min/max labels
    ctx.fillStyle = "#94a3b8"
    ctx.font = "12px sans-serif"
    ctx.textAlign = "right"
    ctx.fillText(`${Math.round(maxInterval)} ms`, padding - 5, padding + 20)
    ctx.fillText(`${Math.round(minInterval)} ms`, padding - 5, canvas.height - padding)
  }

  // Draw typing speed visualization
  const drawTypingSpeed = (
    ctx: CanvasRenderingContext2D,
    canvas: HTMLCanvasElement,
    speedData: { time: number; wpm: number }[],
  ) => {
    if (speedData.length < 2) return

    // Draw title
    ctx.fillStyle = "#f1f5f9"
    ctx.font = "14px sans-serif"
    ctx.textAlign = "center"
    ctx.fillText("Typing Speed Over Time", canvas.width / 2, 20)

    // Find min and max for scaling
    const minWpm = Math.min(...speedData.map((d) => d.wpm))
    const maxWpm = Math.max(...speedData.map((d) => d.wpm))
    const wpmRange = maxWpm - minWpm || 1

    const minTime = speedData[0].time
    const maxTime = speedData[speedData.length - 1].time
    const timeRange = maxTime - minTime || 1

    // Draw line chart
    const padding = 40
    const chartWidth = canvas.width - padding * 2
    const chartHeight = canvas.height - padding * 2 - 20

    // Draw axes
    ctx.strokeStyle = "#475569"
    ctx.beginPath()
    ctx.moveTo(padding, padding + 20)
    ctx.lineTo(padding, canvas.height - padding)
    ctx.lineTo(canvas.width - padding, canvas.height - padding)
    ctx.stroke()

    // Draw WPM line with gradient
    const gradient = ctx.createLinearGradient(padding, padding, padding, canvas.height - padding)
    gradient.addColorStop(0, "rgba(139, 92, 246, 0.8)")
    gradient.addColorStop(1, "rgba(59, 130, 246, 0.2)")

    ctx.beginPath()
    ctx.fillStyle = gradient

    // Start at the bottom left
    ctx.moveTo(padding, canvas.height - padding)

    speedData.forEach((point, i) => {
      const x = padding + ((point.time - minTime) / timeRange) * chartWidth
      const normalizedValue = (point.wpm - minWpm) / wpmRange
      const y = canvas.height - padding - normalizedValue * chartHeight

      if (i === 0) {
        ctx.lineTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })

    // Complete the path to create a filled area
    ctx.lineTo(padding + chartWidth, canvas.height - padding)
    ctx.closePath()
    ctx.fill()

    // Draw the line on top of the filled area
    ctx.beginPath()
    ctx.strokeStyle = "#8b5cf6"
    ctx.lineWidth = 2

    speedData.forEach((point, i) => {
      const x = padding + ((point.time - minTime) / timeRange) * chartWidth
      const normalizedValue = (point.wpm - minWpm) / wpmRange
      const y = canvas.height - padding - normalizedValue * chartHeight

      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })

    ctx.stroke()

    // Draw axis labels
    ctx.fillStyle = "#94a3b8"
    ctx.font = "12px sans-serif"
    ctx.textAlign = "right"
    ctx.fillText(`${Math.round(maxWpm)} WPM`, padding - 5, padding + 20)
    ctx.fillText(`${Math.round(minWpm)} WPM`, padding - 5, canvas.height - padding)

    ctx.textAlign = "center"
    ctx.fillText("0s", padding, canvas.height - padding + 15)
    ctx.fillText(`${Math.round(maxTime)}s`, canvas.width - padding, canvas.height - padding + 15)
  }

  return (
    <div className="w-full bg-gray-900/50 border border-purple-900/30 rounded-lg p-4">
      <canvas ref={canvasRef} width={500} height={height} className="w-full h-auto" />
    </div>
  )
}
