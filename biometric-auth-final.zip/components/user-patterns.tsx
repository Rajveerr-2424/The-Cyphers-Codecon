"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { getUserPatterns, removePattern } from "@/app/actions"
import { Trash2 } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

interface UserPatternsProps {
  username: string
}

interface PatternData {
  id: string
  wpm: number
  consistency: number
  device: string
  timeOfDay: string
  date: string
  keyCount: number
}

export function UserPatterns({ username }: UserPatternsProps) {
  const [patterns, setPatterns] = useState<PatternData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Fetch user patterns
  const fetchPatterns = async () => {
    setLoading(true)
    setError(null)

    try {
      const formData = new FormData()
      formData.append("username", username)

      const response = await getUserPatterns(formData)

      if (response.success && response.patterns) {
        setPatterns(response.patterns)
      } else {
        setError(response.message || "Failed to fetch patterns")
      }
    } catch (err) {
      setError("An error occurred while fetching patterns")
    } finally {
      setLoading(false)
    }
  }

  // Delete a pattern
  const handleDelete = async (patternId: string) => {
    try {
      const formData = new FormData()
      formData.append("username", username)
      formData.append("patternId", patternId)

      const response = await removePattern(formData)

      if (response.success) {
        // Remove pattern from state
        setPatterns(patterns.filter((p) => p.id !== patternId))
      } else {
        setError(response.message)
      }
    } catch (err) {
      setError("An error occurred while deleting the pattern")
    }
  }

  // Load patterns on mount
  useEffect(() => {
    if (username) {
      fetchPatterns()
    }
  }, [username])

  if (loading) {
    return (
      <div className="flex justify-center p-8">
        <div className="w-8 h-8 border-4 border-t-purple-500 border-r-transparent border-b-purple-500 border-l-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (error) {
    return <div className="p-4 bg-red-900/20 border border-red-800/30 rounded-md text-red-400">{error}</div>
  }

  if (patterns.length === 0) {
    return (
      <div className="p-4 bg-gray-900/50 border border-purple-900/30 rounded-md text-gray-400 text-center">
        No typing patterns found. Complete the authentication process to create patterns.
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Your Typing Patterns</h3>
        <Button variant="outline" size="sm" onClick={fetchPatterns}>
          Refresh
        </Button>
      </div>

      <div className="border border-purple-900/30 rounded-md overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-900/50 hover:bg-gray-900/70">
              <TableHead>Date</TableHead>
              <TableHead>Device</TableHead>
              <TableHead>Time</TableHead>
              <TableHead className="text-right">WPM</TableHead>
              <TableHead className="text-right">Consistency</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {patterns.map((pattern) => (
              <TableRow key={pattern.id} className="hover:bg-gray-900/30">
                <TableCell>{pattern.date}</TableCell>
                <TableCell>
                  <Badge variant={pattern.device === "desktop" ? "default" : "outline"}>{pattern.device}</Badge>
                </TableCell>
                <TableCell>{pattern.timeOfDay}</TableCell>
                <TableCell className="text-right">{pattern.wpm}</TableCell>
                <TableCell className="text-right">
                  <span
                    className={`px-2 py-1 rounded-full text-xs ${
                      pattern.consistency >= 80
                        ? "bg-green-900/20 text-green-400"
                        : pattern.consistency >= 60
                          ? "bg-yellow-900/20 text-yellow-400"
                          : "bg-red-900/20 text-red-400"
                    }`}
                  >
                    {pattern.consistency}%
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(pattern.id)}
                    className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-900/20"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
