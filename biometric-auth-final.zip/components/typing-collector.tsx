"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import type { KeyEvent, TypingData, EnvironmentInfo } from "@/types"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Keyboard } from "lucide-react"

interface TypingCollectorProps {
  verificationText: string
  onComplete: (typingData: TypingData) => void
  isSubmitting?: boolean
  minLength?: number
  showProgress?: boolean
}

export function TypingCollector({
  verificationText,
  onComplete,
  isSubmitting = false,
  minLength = 5,
  showProgress = true,
}: TypingCollectorProps) {
  const [typedText, setTypedText] = useState("")
  const [keyEvents, setKeyEvents] = useState<KeyEvent[]>([])
  const [progress, setProgress] = useState(0)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Handle key events for typing pattern analysis
  const handleKeyEvent = (e: React.KeyboardEvent, eventType: "keydown" | "keyup") => {
    if (e.key === "Shift" || e.key === "Control" || e.key === "Alt") return

    setKeyEvents((prev) => [
      ...prev,
      {
        key: e.key,
        eventType,
        timestamp: Date.now(),
      },
    ])
  }

  // Calculate progress based on typed text length
  useEffect(() => {
    if (!verificationText) return

    const targetLength = verificationText.length
    const currentLength = typedText.length
    const calculatedProgress = Math.min(100, Math.round((currentLength / targetLength) * 100))
    setProgress(calculatedProgress)
  }, [typedText, verificationText])

  // Focus the textarea when component mounts
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.focus()
    }
  }, [])

  // Handle submission
  const handleSubmit = () => {
    if (typedText.length < minLength) return

    // Detect device type
    const deviceType = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
      ? "mobile"
      : "desktop"

    // Determine time of day
    const hour = new Date().getHours()
    let timeOfDay = "morning"
    if (hour >= 12 && hour < 17) timeOfDay = "afternoon"
    else if (hour >= 17) timeOfDay = "evening"

    const environmentInfo: EnvironmentInfo = {
      deviceType,
      timeOfDay,
    }

    // Create typing data object
    const typingData: TypingData = {
      text: typedText,
      keyEvents,
      environmentInfo,
    }

    onComplete(typingData)
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="p-3 rounded-md bg-gray-800/50 border border-purple-900/30 text-sm text-gray-400">
          {verificationText}
        </div>
        <textarea
          ref={textareaRef}
          placeholder="Type the text above..."
          className="w-full h-24 p-3 rounded-md bg-gray-900/50 border border-purple-900/50 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
          value={typedText}
          onChange={(e) => setTypedText(e.target.value)}
          onKeyDown={(e) => handleKeyEvent(e, "keydown")}
          onKeyUp={(e) => handleKeyEvent(e, "keyup")}
          disabled={isSubmitting}
        />
      </div>

      {showProgress && (
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-400">Progress</span>
            <span className="text-xs text-gray-400">{progress}%</span>
          </div>
          <Progress value={progress} className="h-1.5 bg-gray-800">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
              style={{ width: `${progress}%` }}
            />
          </Progress>
        </div>
      )}

      <Button
        onClick={handleSubmit}
        disabled={isSubmitting || typedText.length < minLength}
        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
      >
        <Keyboard className="mr-2 h-4 w-4" />
        {isSubmitting ? "Processing..." : "Submit Typing Sample"}
      </Button>
    </div>
  )
}
