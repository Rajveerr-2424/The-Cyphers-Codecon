export interface User {
  id: string
  username: string
  typingPatterns: TypingPattern[]
  createdAt: Date
  updatedAt: Date
}

export interface TypingPattern {
  id: string
  keyHoldTimes: Record<string, number[]> // Hold time for each key
  keyIntervals: number[] // Time between keypresses
  digraphTimes: Record<string, number[]> // Time for common key pairs
  averageWpm: number
  varianceScore: number // Measure of consistency
  lastUpdated: Date
  environmentInfo: EnvironmentInfo
}

export interface EnvironmentInfo {
  deviceType: string
  timeOfDay: string
  physicalState?: string // Optional user-reported state (tired, alert, etc.)
}

export interface KeyEvent {
  key: string
  eventType: "keydown" | "keyup"
  timestamp: number
}

export interface TypingData {
  text: string
  keyEvents: KeyEvent[]
  environmentInfo: EnvironmentInfo
}

export interface AuthResult {
  success: boolean
  confidenceScore: number
  metrics: {
    wpm: number
    keyHoldTime: number
    rhythmConsistency: number
    confidenceScore: number
  }
  message: string
  adaptiveLearning?: boolean // Whether the system learned from this attempt
}

export interface FeatureVector {
  averageHoldTime: number
  holdTimeVariance: number
  averageInterval: number
  intervalVariance: number
  commonDigraphTimes: Record<string, number>
  wpm: number
}

export interface AuthenticationThresholds {
  minConfidenceScore: number
  maxVarianceAllowed: number
  adaptiveLearningThreshold: number
}
