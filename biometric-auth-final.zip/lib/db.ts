import type { User, TypingPattern, EnvironmentInfo } from "@/types"
import { v4 as uuidv4 } from "uuid"

// In a real app, this would connect to a database
// For demo purposes, we'll use an in-memory store
const users: User[] = [
  {
    id: "1",
    username: "demo",
    typingPatterns: [
      {
        id: "pattern-1",
        keyHoldTimes: {
          t: [120, 125, 118, 122],
          h: [100, 105, 98, 102],
          e: [90, 95, 92, 88],
          // More keys would be here in a real implementation
        },
        keyIntervals: [210, 220, 200, 230, 215],
        digraphTimes: {
          th: [220, 225, 218],
          he: [200, 205, 198],
          qu: [230, 235, 228],
        },
        averageWpm: 65,
        varianceScore: 0.15, // Lower is more consistent
        lastUpdated: new Date(),
        environmentInfo: {
          deviceType: "desktop",
          timeOfDay: "morning",
        },
      },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

export async function findUserByUsername(username: string): Promise<User | null> {
  return users.find((user) => user.username === username) || null
}

export async function createUser(username: string, typingPattern: TypingPattern): Promise<User> {
  const newUser: User = {
    id: uuidv4(),
    username,
    typingPatterns: [typingPattern],
    createdAt: new Date(),
    updatedAt: new Date(),
  }

  users.push(newUser)
  return newUser
}

export async function addTypingPattern(userId: string, typingPattern: TypingPattern): Promise<User | null> {
  const userIndex = users.findIndex((user) => user.id === userId)
  if (userIndex === -1) return null

  // Add new pattern to the user's patterns
  users[userIndex].typingPatterns.push(typingPattern)
  users[userIndex].updatedAt = new Date()

  return users[userIndex]
}

export async function getUserTypingPatterns(
  userId: string,
  environmentInfo?: Partial<EnvironmentInfo>,
): Promise<TypingPattern[]> {
  const user = users.find((user) => user.id === userId)
  if (!user) return []

  // If environment info is provided, filter patterns by similar environment
  if (environmentInfo) {
    return user.typingPatterns.filter((pattern) => {
      let match = true
      if (environmentInfo.deviceType && pattern.environmentInfo.deviceType !== environmentInfo.deviceType) {
        match = false
      }
      if (environmentInfo.timeOfDay && pattern.environmentInfo.timeOfDay !== environmentInfo.timeOfDay) {
        match = false
      }
      return match
    })
  }

  return user.typingPatterns
}

// Get the most recent typing patterns (up to limit)
export async function getRecentTypingPatterns(userId: string, limit = 5): Promise<TypingPattern[]> {
  const user = users.find((user) => user.id === userId)
  if (!user) return []

  // Sort by lastUpdated and take the most recent ones
  return [...user.typingPatterns].sort((a, b) => b.lastUpdated.getTime() - a.lastUpdated.getTime()).slice(0, limit)
}

// Delete a specific typing pattern
export async function deleteTypingPattern(userId: string, patternId: string): Promise<boolean> {
  const userIndex = users.findIndex((user) => user.id === userId)
  if (userIndex === -1) return false

  const patternIndex = users[userIndex].typingPatterns.findIndex((p) => p.id === patternId)
  if (patternIndex === -1) return false

  users[userIndex].typingPatterns.splice(patternIndex, 1)
  users[userIndex].updatedAt = new Date()

  return true
}
