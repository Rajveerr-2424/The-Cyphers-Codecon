import type { TypingData, TypingPattern, AuthResult, FeatureVector, AuthenticationThresholds } from "@/types"
import { findUserByUsername, getUserTypingPatterns, addTypingPattern } from "./db"
import { v4 as uuidv4 } from "uuid"

// Default authentication thresholds
const DEFAULT_THRESHOLDS: AuthenticationThresholds = {
  minConfidenceScore: 75, // Minimum confidence score for authentication
  maxVarianceAllowed: 0.3, // Maximum allowed variance in typing patterns
  adaptiveLearningThreshold: 85, // Minimum confidence score to use for adaptive learning
}

// Calculate typing pattern from raw typing data
export function calculateTypingPattern(typingData: TypingData): TypingPattern {
  const { keyEvents, text, environmentInfo } = typingData
  const keyHoldTimes: Record<string, number[]> = {}
  const keyIntervals: number[] = []
  const digraphTimes: Record<string, number[]> = {}

  // Calculate key hold times
  const keyDownEvents: Record<string, number> = {}
  const keySequence: string[] = []

  keyEvents.forEach((event) => {
    const { key, eventType, timestamp } = event

    if (eventType === "keydown") {
      keyDownEvents[key] = timestamp
      keySequence.push(key)
    } else if (eventType === "keyup" && keyDownEvents[key]) {
      const holdTime = timestamp - keyDownEvents[key]

      if (!keyHoldTimes[key]) {
        keyHoldTimes[key] = []
      }

      keyHoldTimes[key].push(holdTime)
      delete keyDownEvents[key]
    }
  })

  // Calculate intervals between keypresses
  const keydownEvents = keyEvents.filter((event) => event.eventType === "keydown")
  for (let i = 1; i < keydownEvents.length; i++) {
    const interval = keydownEvents[i].timestamp - keydownEvents[i - 1].timestamp
    keyIntervals.push(interval)
  }

  // Calculate digraph times (time to type common pairs of characters)
  for (let i = 1; i < keySequence.length; i++) {
    const digraph = keySequence[i - 1] + keySequence[i]
    const currentKeyDown = keyEvents.find((e) => e.eventType === "keydown" && e.key === keySequence[i])
    const prevKeyDown = keyEvents.find((e) => e.eventType === "keydown" && e.key === keySequence[i - 1])

    if (currentKeyDown && prevKeyDown) {
      const digraphTime = currentKeyDown.timestamp - prevKeyDown.timestamp

      if (!digraphTimes[digraph]) {
        digraphTimes[digraph] = []
      }

      digraphTimes[digraph].push(digraphTime)
    }
  }

  // Calculate WPM
  const firstKeydown = keyEvents.find((e) => e.eventType === "keydown")?.timestamp || 0
  const lastKeyup = [...keyEvents].reverse().find((e) => e.eventType === "keyup")?.timestamp || 0

  const timeInMinutes = (lastKeyup - firstKeydown) / 1000 / 60
  const words = text.trim().split(/\s+/).length
  const averageWpm = timeInMinutes > 0 ? Math.round(words / timeInMinutes) : 0

  // Calculate variance score (measure of consistency)
  const varianceScore = calculateVarianceScore(keyHoldTimes, keyIntervals)

  return {
    id: uuidv4(),
    keyHoldTimes,
    keyIntervals,
    digraphTimes,
    averageWpm,
    varianceScore,
    lastUpdated: new Date(),
    environmentInfo,
  }
}

// Calculate variance score from typing data
function calculateVarianceScore(keyHoldTimes: Record<string, number[]>, keyIntervals: number[]): number {
  // Calculate coefficient of variation for hold times
  let totalCV = 0
  let keyCount = 0

  Object.keys(keyHoldTimes).forEach((key) => {
    if (keyHoldTimes[key].length > 1) {
      const mean = average(keyHoldTimes[key])
      const variance =
        keyHoldTimes[key].reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / keyHoldTimes[key].length
      const stdDev = Math.sqrt(variance)
      const cv = stdDev / mean
      totalCV += cv
      keyCount++
    }
  })

  // Calculate coefficient of variation for intervals
  let intervalCV = 0
  if (keyIntervals.length > 1) {
    const mean = average(keyIntervals)
    const variance = keyIntervals.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / keyIntervals.length
    const stdDev = Math.sqrt(variance)
    intervalCV = stdDev / mean
  }

  // Combine both metrics (weighted average)
  const keyHoldWeight = 0.6
  const intervalWeight = 0.4

  const keyHoldCV = keyCount > 0 ? totalCV / keyCount : 0
  const varianceScore = keyHoldCV * keyHoldWeight + intervalCV * intervalWeight

  return Math.min(1, Math.max(0, varianceScore))
}

// Extract feature vector from typing pattern
function extractFeatureVector(pattern: TypingPattern): FeatureVector {
  // Calculate average hold time across all keys
  let totalHoldTime = 0
  let totalHoldCount = 0
  const holdTimeVariances: number[] = []

  Object.keys(pattern.keyHoldTimes).forEach((key) => {
    const times = pattern.keyHoldTimes[key]
    if (times.length > 0) {
      const mean = average(times)
      totalHoldTime += mean * times.length
      totalHoldCount += times.length

      if (times.length > 1) {
        const variance = times.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / times.length
        holdTimeVariances.push(variance)
      }
    }
  })

  const averageHoldTime = totalHoldCount > 0 ? totalHoldTime / totalHoldCount : 0
  const holdTimeVariance = holdTimeVariances.length > 0 ? average(holdTimeVariances) : 0

  // Calculate average interval
  const averageInterval = pattern.keyIntervals.length > 0 ? average(pattern.keyIntervals) : 0

  // Calculate interval variance
  let intervalVariance = 0
  if (pattern.keyIntervals.length > 1) {
    const mean = averageInterval
    intervalVariance =
      pattern.keyIntervals.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / pattern.keyIntervals.length
  }

  // Extract common digraph times
  const commonDigraphTimes: Record<string, number> = {}
  Object.keys(pattern.digraphTimes).forEach((digraph) => {
    if (pattern.digraphTimes[digraph].length > 0) {
      commonDigraphTimes[digraph] = average(pattern.digraphTimes[digraph])
    }
  })

  return {
    averageHoldTime,
    holdTimeVariance,
    averageInterval,
    intervalVariance,
    commonDigraphTimes,
    wpm: pattern.averageWpm,
  }
}

// Compare typing patterns to authenticate user
export async function authenticateUser(
  username: string,
  typingData: TypingData,
  thresholds: AuthenticationThresholds = DEFAULT_THRESHOLDS,
): Promise<AuthResult> {
  const user = await findUserByUsername(username)

  if (!user) {
    return {
      success: false,
      confidenceScore: 0,
      metrics: { wpm: 0, keyHoldTime: 0, rhythmConsistency: 0, confidenceScore: 0 },
      message: "User not found",
    }
  }

  // Calculate current typing pattern
  const currentPattern = calculateTypingPattern(typingData)

  // Get relevant typing patterns for comparison
  // Filter by environment if possible
  const relevantPatterns = await getUserTypingPatterns(user.id, { deviceType: typingData.environmentInfo.deviceType })

  if (relevantPatterns.length === 0) {
    return {
      success: false,
      confidenceScore: 0,
      metrics: { wpm: 0, keyHoldTime: 0, rhythmConsistency: 0, confidenceScore: 0 },
      message: "No typing patterns available for comparison",
    }
  }

  // Calculate confidence score based on pattern similarity
  const confidenceScore = calculateConfidenceScore(currentPattern, relevantPatterns)

  // Calculate rhythm consistency (inverse of variance score)
  const rhythmConsistency = Math.round((1 - currentPattern.varianceScore) * 100)

  // Calculate average key hold time for metrics display
  const allHoldTimes = Object.values(currentPattern.keyHoldTimes).flat()
  const avgKeyHoldTime =
    allHoldTimes.length > 0 ? Math.round(allHoldTimes.reduce((sum, time) => sum + time, 0) / allHoldTimes.length) : 0

  const success =
    confidenceScore >= thresholds.minConfidenceScore && currentPattern.varianceScore <= thresholds.maxVarianceAllowed

  // Adaptive learning: If confidence is high enough but not perfect, add this pattern
  let adaptiveLearning = false
  if (confidenceScore >= thresholds.adaptiveLearningThreshold && confidenceScore < 95) {
    await addTypingPattern(user.id, currentPattern)
    adaptiveLearning = true
  }

  return {
    success,
    confidenceScore,
    metrics: {
      wpm: currentPattern.averageWpm,
      keyHoldTime: avgKeyHoldTime,
      rhythmConsistency,
      confidenceScore,
    },
    message: success ? "Authentication successful" : "Authentication failed",
    adaptiveLearning,
  }
}

// Calculate similarity between typing patterns
function calculateConfidenceScore(current: TypingPattern, storedPatterns: TypingPattern[]): number {
  // Extract feature vectors
  const currentFeatures = extractFeatureVector(current)

  // Calculate similarity scores against each stored pattern
  const similarityScores = storedPatterns.map((pattern) => {
    const storedFeatures = extractFeatureVector(pattern)
    return calculateSimilarity(currentFeatures, storedFeatures)
  })

  // Use the highest similarity score (best match)
  const bestScore = Math.max(...similarityScores)
  return Math.round(bestScore * 100)
}

// Calculate similarity between feature vectors
function calculateSimilarity(current: FeatureVector, stored: FeatureVector): number {
  let totalScore = 0
  let totalWeight = 0

  // Compare hold times (weight: 0.25)
  const holdTimeSimilarity = calculateValueSimilarity(
    current.averageHoldTime,
    stored.averageHoldTime,
    20, // Allow 20ms difference
  )
  totalScore += holdTimeSimilarity * 0.25
  totalWeight += 0.25

  // Compare intervals (weight: 0.25)
  const intervalSimilarity = calculateValueSimilarity(
    current.averageInterval,
    stored.averageInterval,
    30, // Allow 30ms difference
  )
  totalScore += intervalSimilarity * 0.25
  totalWeight += 0.25

  // Compare WPM (weight: 0.15)
  const wpmSimilarity = calculateValueSimilarity(
    current.wpm,
    stored.wpm,
    10, // Allow 10 WPM difference
  )
  totalScore += wpmSimilarity * 0.15
  totalWeight += 0.15

  // Compare digraph times (weight: 0.35)
  let digraphScore = 0
  let digraphCount = 0

  // Find common digraphs between current and stored
  const commonDigraphs = Object.keys(current.commonDigraphTimes).filter(
    (digraph) => stored.commonDigraphTimes[digraph] !== undefined,
  )

  commonDigraphs.forEach((digraph) => {
    const similarity = calculateValueSimilarity(
      current.commonDigraphTimes[digraph],
      stored.commonDigraphTimes[digraph],
      25, // Allow 25ms difference
    )
    digraphScore += similarity
    digraphCount++
  })

  if (digraphCount > 0) {
    totalScore += (digraphScore / digraphCount) * 0.35
    totalWeight += 0.35
  }

  // Return normalized score
  return totalWeight > 0 ? totalScore / totalWeight : 0
}

// Calculate similarity between two numeric values
function calculateValueSimilarity(value1: number, value2: number, tolerance: number): number {
  if (value1 === 0 || value2 === 0) return 0

  const diff = Math.abs(value1 - value2)
  const maxValue = Math.max(value1, value2)

  // If difference is within tolerance, high similarity
  if (diff <= tolerance) {
    return 1 - diff / tolerance / 2 // At most reduce by 50% within tolerance
  }

  // Beyond tolerance, similarity drops more quickly
  const percentDiff = diff / maxValue
  return Math.max(0, 1 - percentDiff * 2)
}

// Helper function to calculate average
function average(numbers: number[]): number {
  return numbers.length > 0 ? numbers.reduce((sum, num) => sum + num, 0) / numbers.length : 0
}

// Extract typing metrics for visualization
export function extractTypingMetrics(typingData: TypingData) {
  const { keyEvents } = typingData

  // Key press frequency
  const keyFrequency: Record<string, number> = {}
  keyEvents
    .filter((e) => e.eventType === "keydown")
    .forEach((e) => {
      if (!keyFrequency[e.key]) keyFrequency[e.key] = 0
      keyFrequency[e.key]++
    })

  // Hold times by key
  const keyHoldTimes: Record<string, number[]> = {}
  const keyDownEvents: Record<string, number> = {}

  keyEvents.forEach((event) => {
    const { key, eventType, timestamp } = event

    if (eventType === "keydown") {
      keyDownEvents[key] = timestamp
    } else if (eventType === "keyup" && keyDownEvents[key]) {
      const holdTime = timestamp - keyDownEvents[key]

      if (!keyHoldTimes[key]) {
        keyHoldTimes[key] = []
      }

      keyHoldTimes[key].push(holdTime)
      delete keyDownEvents[key]
    }
  })

  // Calculate typing rhythm (intervals between keystrokes)
  const keydownEvents = keyEvents.filter((e) => e.eventType === "keydown")
  const intervals: number[] = []

  for (let i = 1; i < keydownEvents.length; i++) {
    intervals.push(keydownEvents[i].timestamp - keydownEvents[i - 1].timestamp)
  }

  // Calculate typing speed over time
  const speedOverTime: { time: number; wpm: number }[] = []
  if (keydownEvents.length > 10) {
    const windowSize = 10 // Calculate WPM over 10 keystrokes
    const startTime = keydownEvents[0].timestamp

    for (let i = windowSize; i < keydownEvents.length; i++) {
      const windowStart = keydownEvents[i - windowSize].timestamp
      const windowEnd = keydownEvents[i].timestamp
      const timeInMinutes = (windowEnd - windowStart) / 1000 / 60

      if (timeInMinutes > 0) {
        // Assuming 5 keystrokes per word on average
        const estimatedWords = windowSize / 5
        const wpm = Math.round(estimatedWords / timeInMinutes)
        speedOverTime.push({
          time: (windowEnd - startTime) / 1000, // Seconds since start
          wpm,
        })
      }
    }
  }

  return {
    keyFrequency,
    keyHoldTimes,
    intervals,
    speedOverTime,
  }
}
